const {performance, PerformanceObserver} = require ('perf_hooks');
const {entriesStatistics}                = require ('../utils/perf_utils');

const obs = new PerformanceObserver ((entries) => {
  obs.disconnect ();
  console.log (entriesStatistics (entries.getEntries (), [ 'count', 'sum', 'avg', 'perSecond', 'stddev' ]));
});
obs.observe ({entryTypes : [ 'function' ], buffered : true});

const g1 = performance.timerify (function getAllPropertyNames1 (obj) {
  const proto = Object.getPrototypeOf (obj);
  return (
    (proto !== null ? getAllPropertyNames1 (proto) : [])
      .concat (Object.getOwnPropertyNames (obj))
      .filter (function (item, pos, result) {
        return result.indexOf (item) === pos;
      })
      .sort ()
  );
});

const g2 = performance.timerify (function getAllPropertyNames2 (obj) {
  const proto = Object.getPrototypeOf (obj);
  return (
    (proto !== null ? getAllPropertyNames2 (proto) : [])
      .concat (Object.getOwnPropertyNames (obj))
      .filter (function (item, pos, result) {
        return result.indexOf (item) === pos;
      })
  );
});

const g3 = performance.timerify (function getAllPropertyNames3 (obj) {
  const result = new Set ();
  let next     = obj;
  do {
    Object.getOwnPropertyNames (next).forEach (e => result.add (e));
  } while (null !== (next = Object.getPrototypeOf (next)));
  return [ ...result ];
});

const g4 = performance.timerify (function getAllPropertyNames4 (obj) {
  const result = new Set ();
  let next     = obj;
  do {
    Object.getOwnPropertyNames (next).forEach (e => result.add (e));
  } while (null !== (next = Object.getPrototypeOf (next)));
  return [ ...result ].sort ();
});

class A extends Array {
  m1 () { /*...*/}
  m2 () { /*...*/}
}

class AA extends A {
  m3 () { /*...*/}
  m4 () { /*...*/}
}

const aa = new AA ();

for (let n = 0; n < 100000; n++) {
  g4 (aa);
  g3 (aa);
  g2 (aa);
  g1 (aa);
}