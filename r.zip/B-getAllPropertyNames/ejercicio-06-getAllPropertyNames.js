const {performance, PerformanceObserver} = require ('perf_hooks');
const {entriesStatistics}                = require ('../utils/perf_utils');

const obs = new PerformanceObserver ((timeline) => {
  obs.disconnect ();
  console.log (entriesStatistics (timeline.getEntries (), [ 'count', 'sum', 'perSecond', 'avg', 'stddev' ]));
});
obs.observe ({entryTypes : [ 'function' ], buffered : true});

Array.prototype.concat = performance.timerify (Array.prototype.concat);
Array.prototype.filter = performance.timerify (Array.prototype.filter);
// Array.prototype.indexOf = performance.timerify(Array.prototype.indexOf);
Array.prototype.sort   = performance.timerify (Array.prototype.sort);

function getPropertyNames (obj) {
  const proto = Object.getPrototypeOf (obj);
  return (
    (proto !== null ? getPropertyNames (proto) : [])
      .concat (Object.getOwnPropertyNames (obj))
      .filter (function (item, pos, result) {
        return result.indexOf (item) === pos;
      })
      .sort ()
  );
}

class A extends Array {
  m1 () { /*...*/}
  m2 () { /*...*/}
}

class AA extends A {
  m3 () { /*...*/}
  m4 () { /*...*/}
}

const aa = new AA ();

// console.log(g2(aa).length);
// console.log(g3(aa).length);

for (let n = 0; n < 20000; n++) {
  getPropertyNames (aa);
}