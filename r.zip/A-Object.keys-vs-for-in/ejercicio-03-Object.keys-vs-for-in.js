const {performance, PerformanceObserver} = require ('perf_hooks');

const obs = new PerformanceObserver ((timeline) => {
  obs.disconnect ();
  console.log (timeline.getEntries ());
});
obs.observe ({entryTypes : [ 'measure' ], buffered : true});

const bigObject = {
  a : 1, b : 2, c : 3, d : 4, e : 5,
  f : 6, g : 7, h : 8, i : 9, j : 10,
  k : 11, l : 12, m : 13, n : 14, o : 15,
  p : 16, q : 17, r : 18, s : 19, t : 20,
  u : 21, v : 22, w : 23, x : 24, y : 25,
  z : 26
};

// For in
performance.mark ('for in - start');
const resultA = [];
for (let c in bigObject) {
  resultA.push (c);
}
performance.mark ('for in - end');
performance.measure ('for in', 'for in - start', 'for in - end');
console.assert (resultA.length === 26);

// Object.keys()
performance.mark ('Object.keys() - start');
const resultB = Object.keys (bigObject);
performance.mark ('Object.keys() - end');
performance.measure ('Object.keys()', 'Object.keys() - start', 'Object.keys() - end');
console.assert (resultB.length === 26);
