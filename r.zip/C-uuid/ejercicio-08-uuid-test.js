const {performance, PerformanceObserver} = require ('perf_hooks');
const {entriesStatistics} = require('../../lib/perf_utils');
const obs = new PerformanceObserver((tm) => {
  obs.disconnect();
  console.log(entriesStatistics(tm.getEntries(), ['sum', 'avg', 'perSecond', 'stddev']));
});
obs.observe({entryTypes: ['measure'], buffered: true});

[
  ['uuid/v4',   require ('uuid/v4')],         // https://github.com/broofa/node-uuid
  ['nanoid',    require ('nanoid')],          // https://github.com/ai/nanoid
  ['hyperid',   require ('hyperid')()],       // https://github.com/mcollina/hyperid
  ['fast-uuid', require ('./fast-uuid').v4],  // https://bl.ocks.org/solderjs/7e5ebb9a6708d0ebfc78
  ['custom',    require ('./micro-uuid')]
].forEach(p => {
  const name = p[0];
  const uuid = p[1];
  const loops = 100000;
  const check = new Set ();
  for (let n = 0; n < loops; n++) {
    performance.mark(`${name} start`);
    const result = uuid ();
    performance.mark(`${name} end`);
    performance.measure(name, `${name} start`, `${name} end`);
    check.add (result);
  }
  console.assert (check.size === loops);
});