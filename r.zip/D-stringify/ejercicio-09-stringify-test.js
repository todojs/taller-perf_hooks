const {performance, PerformanceObserver} = require ('perf_hooks');
const {entriesStatistics}                = require ('../utils/perf_utils');
const fastJson                           = require ('fast-json-stringify');
const stringifyFast                      = performance.timerify (fastJson (require ('./schema.json')));
const stringifyOriginal                  = performance.timerify (JSON.stringify);
const data                               = require ('./data.json');

const obs = new PerformanceObserver ((timeline) => {
  obs.disconnect ();
  console.log (entriesStatistics (timeline.getEntries ()));
});
obs.observe ({entryTypes : [ 'measure' ], buffered: true});

for (let n = 0; n < 100000; n++) {
  performance.mark('fast init');
  const r1 = stringifyFast(data);
  performance.mark('fast end');
  performance.measure('fast', 'fast start', 'fast end');
  
  performance.mark('original init');
  const r2 = stringifyOriginal(data);
  performance.mark('original end');
  performance.measure('original', 'original start', 'original end');
}
